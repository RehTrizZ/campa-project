import cv2
from PIL import Image
import numpy as np

def arrayToMatrix():
    np.set_printoptions(threshold=np.inf)
    img = Image.open("IR_0015.jpg").convert("RGB")
    arr = np.array(img)
    hex_matrix = np.apply_along_axis(lambda rgb: "#{:02X}{:02X}{:02X}".format(*rgb), 2, arr)
    print(hex_matrix.shape)  # (altezza, larghezza)
    print(hex_matrix)  # Stampa la matrice esadecimale

arrayToMatrix()

print("Fine del programma")